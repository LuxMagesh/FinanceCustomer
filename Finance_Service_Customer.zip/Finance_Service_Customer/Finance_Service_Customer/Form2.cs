﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Finance_Service_Customer
{
    public partial class Form2 : Form
    {
        
        public Form2()
        {
            InitializeComponent();
        }
         private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'financeClientsDataSet.Customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter.Fill(this.financeClientsDataSet.Customer);

        }

        
        
    }
}
